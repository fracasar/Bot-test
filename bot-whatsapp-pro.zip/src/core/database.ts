
import { Low } from "lowdb";
import { JSONFile } from "lowdb/node";

type Data = {
  users: Record<string, any>;
  groups: Record<string, any>;
  premium: string[];
};

const adapter = new JSONFile<Data>("database.json");
export const db = new Low<Data>(adapter, { users: {}, groups: {}, premium: [] });

export async function initDB() {
  await db.read();
  db.data ||= { users: {}, groups: {}, premium: [] };
  await db.write();
}
