
import config from "../config";
import { db } from "./database";

export async function messageHandler(sock: any, msg: any, commands: Map<string, any>) {
  if (!msg.message) return;

  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || jid;

  const text =
    msg.message.conversation ||
    msg.message.extendedTextMessage?.text ||
    "";

  if (!text.startsWith(config.prefix)) return;

  const args = text.slice(config.prefix.length).trim().split(/ +/);
  const commandName = (args.shift() || "").toLowerCase();
  const command = commands.get(commandName);
  if (!command) return;

  const isPremium = db.data?.premium?.includes(sender);

  try {
    if (command.premium && !isPremium) {
      return sock.sendMessage(jid, { text: "❌ Comando premium." });
    }
    await command.execute(sock, msg, args, { isPremium });
  } catch (e) {
    console.error(e);
  }
}
