
import fs from "fs";
import path from "path";

export function loadFolder(folder: string) {
  const map = new Map();
  const full = path.join(__dirname, "..", folder);
  if (!fs.existsSync(full)) return map;

  const files = fs.readdirSync(full).filter(f => f.endsWith(".ts") || f.endsWith(".js"));
  for (const file of files) {
    const mod = require(`../${folder}/${file}`);
    const item = mod.default || mod;
    if (item?.name) map.set(item.name, item);
  }
  return map;
}
