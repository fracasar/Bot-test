
export default {
  name: "antilink",
  async run(sock: any, msg: any) {
    const text =
      msg.message?.conversation ||
      msg.message?.extendedTextMessage?.text ||
      "";
    if (text.includes("http")) {
      await sock.sendMessage(msg.key.remoteJid, { text: "🚫 Links no permitidos." });
    }
  },
};
