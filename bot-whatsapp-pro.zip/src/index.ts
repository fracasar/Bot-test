
import { createClient } from "./core/client";
import { loadFolder } from "./core/loader";
import { messageHandler } from "./core/handler";
import { initDB } from "./core/database";
import { startWeb } from "./web/server";

async function start() {
  await initDB();

  const commands = loadFolder("commands");
  const plugins = loadFolder("plugins");

  const sock = await createClient(start);

  startWeb();

  sock.ev.on("messages.upsert", async ({ messages }) => {
    const msg = messages[0];
    if (!msg || msg.key.fromMe) return;

    for (const [, plugin] of plugins) {
      if (plugin.run) await plugin.run(sock, msg);
    }

    await messageHandler(sock, msg, commands);
  });
}

start();
