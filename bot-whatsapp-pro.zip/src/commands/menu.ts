
export default {
  name: "menu",
  async execute(sock: any, msg: any) {
    await sock.sendMessage(msg.key.remoteJid, {
      text: "📜 Menú:\n!ping\n!premiumtest",
    });
  },
};
