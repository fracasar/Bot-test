
export default {
  name: "premiumtest",
  premium: true,
  async execute(sock: any, msg: any) {
    await sock.sendMessage(msg.key.remoteJid, { text: "⭐ Comando premium funcionando." });
  },
};
