
export default {
  name: "ping",
  description: "Responde pong",
  async execute(sock: any, msg: any) {
    await sock.sendMessage(msg.key.remoteJid, { text: "🏓 Pong!" });
  },
};
