
export default {
  prefix: process.env.PREFIX || "!",
  owner: process.env.OWNER || "",
  port: Number(process.env.PORT || 3000),
};
