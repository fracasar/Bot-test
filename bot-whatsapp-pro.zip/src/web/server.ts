
import express from "express";
import config from "../config";
import { db } from "../core/database";

export function startWeb() {
  const app = express();
  app.use(express.json());

  app.get("/", (_req, res) => {
    res.json({ status: "ok", users: Object.keys(db.data?.users || {}).length });
  });

  app.post("/premium", async (req, res) => {
    const { number } = req.body;
    if (!number) return res.status(400).json({ error: "number required" });
    db.data!.premium.push(number);
    await db.write();
    res.json({ ok: true });
  });

  app.listen(config.port, () => {
    console.log(`🌐 Panel web en http://localhost:${config.port}`);
  });
}
